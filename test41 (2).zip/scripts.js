document.addEventListener("DOMContentLoaded", function () {
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;

    // Check for saved theme in local storage
    if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-mode');
        themeToggle.textContent = '🌕'; // Moon icon for dark mode
    } else {
        body.classList.remove('dark-mode');
        themeToggle.textContent = '🌙'; // Sun icon for light mode
    }

    themeToggle.addEventListener('click', function () {
        body.classList.toggle('dark-mode');
        if (body.classList.contains('dark-mode')) {
            themeToggle.textContent = '🌕'; // Moon icon for dark mode
            localStorage.setItem('theme', 'dark');
        } else {
            themeToggle.textContent = '🌙'; // Sun icon for light mode
            localStorage.setItem('theme', 'light');
        }
    });

    // Automatic carousel slide
    $('.carousel').carousel({
        interval: 3000 // Time in milliseconds
    });

    // Card expansion functionality
    const viewButtons = document.querySelectorAll('.view-button');
    viewButtons.forEach(button => {
        button.addEventListener('click', () => {
            const cardContent = button.previousElementSibling; // The .card-content div
            cardContent.classList.toggle('expanded');
            button.textContent = cardContent.classList.contains('expanded') ? 'Hide' : 'View';
        });
    });
});




document.addEventListener("DOMContentLoaded", function () {
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;
    const themeIcon = themeToggle.querySelector('i');

    // Check for saved theme in local storage
    if (localStorage.getItem('theme') === 'dark') {
        body.classList.add('dark-mode');
        themeIcon.classList.remove('fa-sun');
        themeIcon.classList.add('fa-moon');
    } else {
        body.classList.remove('dark-mode');
        themeIcon.classList.remove('fa-moon');
        themeIcon.classList.add('fa-sun');
    }

    themeToggle.addEventListener('click', function () {
        body.classList.toggle('dark-mode');
        if (body.classList.contains('dark-mode')) {
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-moon');
            localStorage.setItem('theme', 'dark');
        } else {
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
            localStorage.setItem('theme', 'light');
        }
    });

    // Automatic carousel slide
    $('.carousel').carousel({
        interval: 3000 // Time in milliseconds
    });

    // Card expansion functionality
    const viewButtons = document.querySelectorAll('.view-button');
    viewButtons.forEach(button => {
        button.addEventListener('click', () => {
            const cardContent = button.previousElementSibling; // The .card-content div
            cardContent.classList.toggle('expanded');
            button.textContent = cardContent.classList.contains('expanded') ? 'Hide' : 'View';
        });
    });
});
